module.exports = {
	dialect: "mysql",
	host: "remotemysql.com",
	port: 3306,
	username: "DdhpAcqcwA",
	database: "DdhpAcqcwA",
	password: "TqLudQ9CWM",
	define: {
		timestamps: true,
		underscored: true,
		underscoredAll: true
	}
};
